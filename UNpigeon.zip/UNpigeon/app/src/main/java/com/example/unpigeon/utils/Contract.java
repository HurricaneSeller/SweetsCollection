package com.example.unpigeon.utils;

public interface Contract {
}
