package com.example.unpigeon.record;

public interface RecordContract {
    interface View{

    }
    interface Presenter{

    }
}
