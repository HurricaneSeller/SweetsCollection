package com.example.unpigeon.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.unpigeon.R;
//no need now, just put it here
public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}
