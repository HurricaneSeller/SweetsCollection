package com.example.unpigeon.main;

public interface MainContract {
    interface View{

    }
    interface Presenter{

    }
}
