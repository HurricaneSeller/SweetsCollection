package com.example.unpigeon.listen;

public interface ListenContract {
    interface ListView{

    }
    interface ListPresenter{

    }
    interface PlayView{

    }
    interface PlayPresenter{

    }
}
