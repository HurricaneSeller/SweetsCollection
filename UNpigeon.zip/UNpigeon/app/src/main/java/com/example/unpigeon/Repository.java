package com.example.unpigeon;

/**
 * store the key to load local record piece here.
 * and every time the app restart, reload the repository
 */
public class Repository {
}
