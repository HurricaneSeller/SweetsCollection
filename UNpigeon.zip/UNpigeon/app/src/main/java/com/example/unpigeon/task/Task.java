package com.example.unpigeon.task;

/*
bean
every audio create a task and add to queue to upload
room to save
 */
public class Task {
    private boolean isRecordFinished;
    private boolean isUploadFished;
}
