package com.example.unpigeon.listen.list;

import com.example.unpigeon.listen.ListenContract;

public class ListPresenter {
    private final ListenContract.ListView mListView;

    public ListPresenter(ListenContract.ListView listView) {
        mListView = listView;
    }
}
