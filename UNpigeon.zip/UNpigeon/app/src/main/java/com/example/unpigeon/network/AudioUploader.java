package com.example.unpigeon.network;

/*
 * encapsulate a uploader for audio-uploading
 * okhttp frame
 * the task-text is not a heavy work so there is no need to encapsulate a downloader now
 */
public class AudioUploader {
}
