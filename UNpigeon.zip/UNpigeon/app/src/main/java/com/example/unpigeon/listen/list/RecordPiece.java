package com.example.unpigeon.listen.list;

public class RecordPiece {
    private String summary;
    private String name;

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
